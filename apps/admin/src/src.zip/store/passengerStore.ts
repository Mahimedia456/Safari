import { create } from "zustand";

import { adminPassengerService } from "../services/passengerService";
import { useAuthStore } from "./authStore";
import type {
  AdminPassenger,
  AdminPassengerDetail,
} from "../types/passenger";

type PassengerState = {
  loading: boolean;
  error: string | null;
  passengers: AdminPassenger[];
  total: number;
  selected: AdminPassengerDetail | null;

  load: (filters?: {
    search?: string;
    status?: string;
    country?: string;
  }) => Promise<void>;

  loadDetail: (passengerId: string) => Promise<void>;

  setStatus: (
    passengerId: string,
    status: "active" | "suspended" | "blocked",
  ) => Promise<void>;
};

function token() {
  const accessToken = useAuthStore.getState().accessToken;

  if (!accessToken) {
    throw new Error("Safari admin session is required.");
  }

  return accessToken;
}

export const usePassengerStore = create<PassengerState>((set, get) => ({
  loading: false,
  error: null,
  passengers: [],
  total: 0,
  selected: null,

  load: async (filters) => {
    set({ loading: true, error: null });

    try {
      const data = await adminPassengerService.list(token(), filters);

      set({
        passengers: data.passengers,
        total: data.total,
      });
    } catch (error) {
      set({
        error:
          error instanceof Error
            ? error.message
            : "Could not load Safari passengers.",
      });
    } finally {
      set({ loading: false });
    }
  },

  loadDetail: async (passengerId) => {
    set({ loading: true, error: null });

    try {
      const selected = await adminPassengerService.detail(
        token(),
        passengerId,
      );

      set({ selected });
    } catch (error) {
      set({
        error:
          error instanceof Error
            ? error.message
            : "Could not load passenger details.",
      });
    } finally {
      set({ loading: false });
    }
  },

  setStatus: async (passengerId, status) => {
    await adminPassengerService.updateStatus(token(), passengerId, status);

    set({
      passengers: get().passengers.map((item) =>
        item.id === passengerId
          ? {
              ...item,
              status,
            }
          : item,
      ),
    });
  },
}));
