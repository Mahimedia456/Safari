import { create } from "zustand";

import { adminFoodService } from "../services/foodService";
import type {
  AdminFoodOrder,
  AdminFoodRestaurant,
} from "../types/food";
import { useAuthStore } from "./authStore";

type FoodState = {
  loading: boolean;
  error: string | null;

  restaurants: AdminFoodRestaurant[];
  orders: AdminFoodOrder[];

  loadRestaurants: () => Promise<void>;
  loadOrders: (status?: string) => Promise<void>;
  updateOrderStatus: (
    orderId: string,
    status:
      | "confirmed"
      | "preparing"
      | "ready_for_pickup"
      | "picked_up"
      | "on_the_way"
      | "delivered"
      | "cancelled_by_merchant"
      | "cancelled_by_admin",
    note?: string | null,
  ) => Promise<void>;
};

function token() {
  const accessToken = useAuthStore.getState().accessToken;

  if (!accessToken) {
    throw new Error("Safari admin session is required.");
  }

  return accessToken;
}

export const useFoodStore = create<FoodState>((set, get) => ({
  loading: false,
  error: null,

  restaurants: [],
  orders: [],

  loadRestaurants: async () => {
    set({ loading: true, error: null });

    try {
      const data = await adminFoodService.restaurants(token());
      set({ restaurants: data.restaurants });
    } catch (error) {
      set({
        error:
          error instanceof Error
            ? error.message
            : "Could not load Safari Food restaurants.",
      });
    } finally {
      set({ loading: false });
    }
  },

  loadOrders: async (status) => {
    set({ loading: true, error: null });

    try {
      const data = await adminFoodService.orders(token(), status);
      set({ orders: data.orders });
    } catch (error) {
      set({
        error:
          error instanceof Error
            ? error.message
            : "Could not load Safari Food orders.",
      });
    } finally {
      set({ loading: false });
    }
  },

  updateOrderStatus: async (orderId, status, note) => {
    await adminFoodService.updateOrderStatus(
      token(),
      orderId,
      status,
      note,
    );

    await get().loadOrders();
  },
}));
