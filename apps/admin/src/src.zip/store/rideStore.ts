import { create } from "zustand";

import { adminRideService } from "../services/rideService";
import type {
  AdminRide,
  RideCatalogAdminData,
} from "../types/ride";
import { useAuthStore } from "./authStore";

type RideState = {
  loading: boolean;
  error: string | null;

  catalog: RideCatalogAdminData | null;
  rides: AdminRide[];
  total: number;
  selected: {
    ride: AdminRide;
    events: Record<string, unknown>[];
  } | null;

  loadCatalog: () => Promise<void>;

  loadRides: (filters?: {
    status?: string;
    cityId?: string;
    search?: string;
  }) => Promise<void>;

  loadRide: (rideId: string) => Promise<void>;

  updatePricing: (
    pricingId: string,
    input: Record<string, unknown>,
  ) => Promise<void>;
};

function token() {
  const accessToken = useAuthStore.getState().accessToken;

  if (!accessToken) {
    throw new Error("Safari admin session is required.");
  }

  return accessToken;
}

export const useRideStore = create<RideState>((set, get) => ({
  loading: false,
  error: null,

  catalog: null,
  rides: [],
  total: 0,
  selected: null,

  loadCatalog: async () => {
    set({ loading: true, error: null });

    try {
      const catalog = await adminRideService.catalog(token());
      set({ catalog });
    } catch (error) {
      set({
        error:
          error instanceof Error
            ? error.message
            : "Could not load Safari ride catalog.",
      });
    } finally {
      set({ loading: false });
    }
  },

  loadRides: async (filters) => {
    set({ loading: true, error: null });

    try {
      const data = await adminRideService.list(
        token(),
        filters,
      );

      set({
        rides: data.rides,
        total: data.total,
      });
    } catch (error) {
      set({
        error:
          error instanceof Error
            ? error.message
            : "Could not load Safari rides.",
      });
    } finally {
      set({ loading: false });
    }
  },

  loadRide: async (rideId) => {
    set({ loading: true, error: null });

    try {
      const selected = await adminRideService.detail(
        token(),
        rideId,
      );

      set({ selected });
    } catch (error) {
      set({
        error:
          error instanceof Error
            ? error.message
            : "Could not load Safari ride details.",
      });
    } finally {
      set({ loading: false });
    }
  },

  updatePricing: async (pricingId, input) => {
    await adminRideService.updatePricing(
      token(),
      pricingId,
      input as any,
    );

    await get().loadCatalog();
  },
}));
