import { create } from "zustand";

import { adminDriverService } from "../services/driverService";
import type {
  AdminDriverDetail,
  AdminDriverListItem,
} from "../types/driver";
import { useAuthStore } from "./authStore";

type DriverState = {
  loading: boolean;
  error: string | null;
  drivers: AdminDriverListItem[];
  total: number;
  selected: AdminDriverDetail | null;

  load: (filters?: {
    search?: string;
    onboardingStatus?: string;
    verificationStatus?: string;
    city?: string;
  }) => Promise<void>;

  loadDetail: (driverId: string) => Promise<void>;

  updateStatus: (
    driverId: string,
    action:
      | "under_review"
      | "approve"
      | "reject"
      | "suspend"
      | "reactivate",
    note?: string | null,
  ) => Promise<void>;

  updateVehicleStatus: (
    driverId: string,
    vehicleId: string,
    status: "verified" | "rejected",
    note?: string | null,
  ) => Promise<void>;

  updateDocumentStatus: (
    driverId: string,
    documentId: string,
    status: "verified" | "rejected",
    note?: string | null,
  ) => Promise<void>;
};

function token() {
  const accessToken = useAuthStore.getState().accessToken;

  if (!accessToken) {
    throw new Error("Safari admin session is required.");
  }

  return accessToken;
}

export const useDriverStore = create<DriverState>((set, get) => ({
  loading: false,
  error: null,
  drivers: [],
  total: 0,
  selected: null,

  load: async (filters) => {
    set({ loading: true, error: null });

    try {
      const data = await adminDriverService.list(token(), filters);

      set({
        drivers: data.drivers,
        total: data.total,
      });
    } catch (error) {
      set({
        error:
          error instanceof Error
            ? error.message
            : "Could not load Safari drivers.",
      });
    } finally {
      set({ loading: false });
    }
  },

  loadDetail: async (driverId) => {
    set({ loading: true, error: null });

    try {
      const selected = await adminDriverService.detail(
        token(),
        driverId,
      );

      set({ selected });
    } catch (error) {
      set({
        error:
          error instanceof Error
            ? error.message
            : "Could not load driver verification details.",
      });
    } finally {
      set({ loading: false });
    }
  },

  updateStatus: async (driverId, action, note) => {
    await adminDriverService.updateDriverStatus(
      token(),
      driverId,
      action,
      note,
    );

    await get().loadDetail(driverId);
    await get().load();
  },

  updateVehicleStatus: async (
    driverId,
    vehicleId,
    status,
    note,
  ) => {
    await adminDriverService.updateVehicleStatus(
      token(),
      driverId,
      vehicleId,
      status,
      note,
    );

    await get().loadDetail(driverId);
  },

  updateDocumentStatus: async (
    driverId,
    documentId,
    status,
    note,
  ) => {
    await adminDriverService.updateDocumentStatus(
      token(),
      driverId,
      documentId,
      status,
      note,
    );

    await get().loadDetail(driverId);
  },
}));
