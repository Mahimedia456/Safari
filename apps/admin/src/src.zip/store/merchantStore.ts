import { create } from "zustand";

import { adminMerchantService } from "../services/merchantService";
import type {
  AdminMerchant,
  AdminUnifiedOrder,
} from "../types/merchant";
import { useAuthStore } from "./authStore";

type MerchantState = {
  loading: boolean;
  error: string | null;

  merchants: AdminMerchant[];
  orders: AdminUnifiedOrder[];

  loadMerchants: (filters?: {
    type?: string;
    verificationStatus?: string;
  }) => Promise<void>;

  loadOrders: () => Promise<void>;
};

function token() {
  const accessToken =
    useAuthStore.getState().accessToken;

  if (!accessToken)
    throw new Error("Safari admin session is required.");

  return accessToken;
}

export const useMerchantStore =
  create<MerchantState>((set) => ({
    loading: false,
    error: null,
    merchants: [],
    orders: [],

    loadMerchants: async (filters) => {
      set({ loading: true, error: null });

      try {
        const data =
          await adminMerchantService.list(
            token(),
            filters,
          );

        set({ merchants: data.merchants });
      } catch (error) {
        set({
          error:
            error instanceof Error
              ? error.message
              : "Could not load Safari merchants.",
        });
      } finally {
        set({ loading: false });
      }
    },

    loadOrders: async () => {
      set({ loading: true, error: null });

      try {
        const data =
          await adminMerchantService.unifiedOrders(
            token(),
          );

        set({ orders: data.orders });
      } catch (error) {
        set({
          error:
            error instanceof Error
              ? error.message
              : "Could not load Safari unified orders.",
        });
      } finally {
        set({ loading: false });
      }
    },
  }));
