import {
  StrictMode,
} from "react";

import {
  createRoot,
} from "react-dom/client";

import {
  RouterProvider,
} from "react-router-dom";

import "./index.css";

import { router } from "./app/router";

import { useAuthStore } from "./store/authStore";
import { useThemeStore } from "./store/themeStore";

useThemeStore
  .getState()
  .initializeTheme();

void useAuthStore
  .getState()
  .initializeAuth();

const rootElement =
  document.getElementById(
    "root",
  );

if (!rootElement) {
  throw new Error(
    "Root element was not found.",
  );
}

createRoot(
  rootElement,
).render(
  <StrictMode>
    <RouterProvider
      router={router}
    />
  </StrictMode>,
);