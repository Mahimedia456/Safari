export type AdminMerchant = {
  user_id: string;
  merchant_type: "food" | "grocery" | "pharmacy" | "services";
  business_name: string | null;
  legal_name: string | null;
  verification_status: string;
  commission_percent: number | string;
  payout_status: string;
  approved_at: string | null;
  rejection_reason: string | null;
};

export type AdminUnifiedOrder = {
  id: string;
  source_type: "food" | "grocery" | "pharmacy" | "services";
  source_id: string;
  order_number: string;
  customer_id: string;
  merchant_user_id: string | null;
  status: string;
  currency_code: string;
  total: number | string | null;
  payment_method: string | null;
  payment_status: string | null;
  created_at: string;
};
