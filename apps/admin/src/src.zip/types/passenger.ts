export type AdminPassenger = {
  id: string;
  full_name: string | null;
  email: string | null;
  phone: string | null;
  avatar_url: string | null;
  status: "pending" | "active" | "suspended" | "blocked";
  country_code: "PK" | "DE";
  is_onboarded: boolean;
  created_at: string;
  last_seen_at: string | null;
};

export type AdminPassengerDetail = {
  passenger: Record<string, unknown>;
  addresses: Record<string, unknown>[];
  preferences: Record<string, unknown> | null;
  emergencyContacts: Record<string, unknown>[];
};
