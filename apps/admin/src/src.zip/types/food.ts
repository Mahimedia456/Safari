export type AdminFoodOrder = {
  id: string;
  order_number: string;
  passenger_id: string;
  restaurant_id: string;
  status: string;
  currency_code: string;
  total: number | string;
  payment_method: string;
  payment_status: string;
  delivery_address: string;
  customer_note: string | null;
  created_at: string;
  food_restaurants?: {
    id: string;
    name: string;
  };
};

export type AdminFoodRestaurant = {
  id: string;
  merchant_user_id: string;
  city_id: string;
  name: string;
  slug: string;
  cuisine: string;
  address: string;
  rating: number | string;
  minimum_order: number | string;
  delivery_fee: number | string;
  is_open: boolean;
  is_active: boolean;
  is_featured: boolean;
};
