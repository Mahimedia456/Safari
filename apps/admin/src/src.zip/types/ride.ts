export type AdminRide = {
  id: string;
  passenger_id: string;
  driver_id: string | null;
  vehicle_id: string | null;
  ride_number: string;
  ride_status: string;
  booking_type: "now" | "scheduled";
  scheduled_for: string | null;
  pickup_address: string;
  dropoff_address: string;
  estimated_distance_km: number | string;
  estimated_duration_minutes: number | string;
  currency_code: string;
  estimated_fare: number | string;
  final_fare: number | string | null;
  payment_method: string;
  payment_status: string;
  created_at: string;
  ride_categories?: {
    code: string;
    name: string;
  };
  service_cities?: {
    name: string;
    city_code: string;
  };
};

export type RideCatalogAdminData = {
  cities: Record<string, unknown>[];
  zones: Record<string, unknown>[];
  categories: Record<string, unknown>[];
  pricing: Record<string, unknown>[];
  settings: Record<string, unknown>[];
};
