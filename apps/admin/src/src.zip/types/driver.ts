export type DriverVerificationStatus =
  | "pending"
  | "in_review"
  | "verified"
  | "rejected"
  | "expired";

export type DriverOnboardingStatus =
  | "draft"
  | "submitted"
  | "under_review"
  | "approved"
  | "rejected"
  | "suspended";

export type AdminDriverListItem = {
  id: string;
  full_name: string | null;
  email: string | null;
  phone: string | null;
  avatar_url: string | null;
  status: string;
  country_code: string;
  is_onboarded: boolean;
  created_at: string;
  driver_profile: {
    user_id: string;
    onboarding_status: DriverOnboardingStatus;
    verification_status: DriverVerificationStatus;
    operating_city: string | null;
    driving_license_number: string | null;
    is_online: boolean;
    is_available: boolean;
    created_at: string;
    updated_at: string;
  };
};

export type AdminDriverDetail = {
  profile: Record<string, unknown>;
  driverProfile: Record<string, unknown>;
  vehicles: Record<string, unknown>[];
  documents: Record<string, unknown>[];
  events: Record<string, unknown>[];
};
